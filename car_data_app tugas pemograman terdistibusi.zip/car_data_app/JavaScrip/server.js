// server.js
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost/car_dealer', { useNewUrlParser: true, useUnifiedTopology: true });

// Car model
const Car = mongoose.model('Car', new mongoose.Schema({
  identifier: Number,
  name: String,
  brand: String,
  model: String,
  year: Number
}));

// CRUD routes
app.get('/cars', async (req, res) => {
  const cars = await Car.find();
  res.json(cars);
});

app.get('/cars/:id', async (req, res) => {
  const car = await Car.findById(req.params.id);
  res.json(car);
});

app.post('/cars', async (req, res) => {
  const newCar = new Car(req.body);
  await newCar.save();
  res.json(newCar);
});

app.put('/cars/:id', async (req, res) => {
  const car = await Car.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(car);
});

app.delete('/cars/:id', async (req, res) => {
  await Car.findByIdAndDelete(req.params.id);
  res.json({ message: 'Car deleted' });
});

app.listen(3000, () => console.log('Server running on port 3000'));
