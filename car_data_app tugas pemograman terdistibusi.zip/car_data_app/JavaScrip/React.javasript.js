// App.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [cars, setCars] = useState([]);
  const [form, setForm] = useState({ identifier: '', name: '', brand: '', model: '', year: '' });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = async () => {
    const response = await axios.get('/cars');
    setCars(response.data);
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editId) {
      await axios.put(`/cars/${editId}`, form);
    } else {
      await axios.post('/cars', form);
    }
    setForm({ identifier: '', name: '', brand: '', model: '', year: '' });
    setEditId(null);
    fetchCars();
  };

  const handleEdit = (car) => {
    setForm(car);
    setEditId(car._id);
  };

  const handleDelete = async (id) => {
    await axios.delete(`/cars/${id}`);
    fetchCars();
  };

  return (
    <div>
      <h1>Car Dealer Inventory</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" name="identifier" value={form.identifier} onChange={handleChange} placeholder="Identifier" />
        <input type="text" name="name" value={form.name} onChange={handleChange} placeholder="Name" />
        <input type="text" name="brand" value={form.brand} onChange={handleChange} placeholder="Brand" />
        <input type="text" name="model" value={form.model} onChange={handleChange} placeholder="Model" />
        <input type="text" name="year" value={form.year} onChange={handleChange} placeholder="Year" />
        <button type="submit">Save</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>Identifier</th>
            <th>Name</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Year</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {cars.map(car => (
            <tr key={car._id}>
              <td>{car.identifier}</td>
              <td>{car.name}</td>
              <td>{car.brand}</td>
              <td>{car.model}</td>
              <td>{car.year}</td>
              <td>
                <button onClick={() => handleEdit(car)}>Edit</button>
                <button onClick={() => handleDelete(car._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;
